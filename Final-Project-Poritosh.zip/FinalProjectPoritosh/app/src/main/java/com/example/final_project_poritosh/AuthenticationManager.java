package com.example.final_project_poritosh;
// AuthenticationManager.java
public class AuthenticationManager {
    private static final String PREF_NAME = "UserPrefs";
    private static final String KEY_USERNAME = "username";
    private static final String KEY_PASSWORD = "password";

    private SharedPreferences preferences;

    public AuthenticationManager(Context context) {
        preferences = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
    }

    public boolean isLoggedIn() {
        return preferences.contains(KEY_USERNAME) && preferences.contains(KEY_PASSWORD);
    }

    public boolean login(String username, String password) {
        // Implement actual authentication logic (e.g., check against a database)
        if (isValidUser(username, password)) {
            preferences.edit()
                    .putString(KEY_USERNAME, username)
                    .putString(KEY_PASSWORD, password)
                    .apply();
            return true;
        }
        return false;
    }

    public void logout() {
        preferences.edit()
                .remove(KEY_USERNAME)
                .remove(KEY_PASSWORD)
                .apply();
    }

    private boolean isValidUser(String username, String password) {
        // Example: Predefined usernames and passwords for demonstration
        String[] validUsernames = {"user1", "user2", "user3"};
        String[] validPasswords = {"password1", "password2", "password3"};

        for (int i = 0; i < validUsernames.length; i++) {
            if (username.equals(validUsernames[i]) && password.equals(validPasswords[i])) {
                return true; // User is valid
            }
        }

        return false; // User is not valid
    }

}

