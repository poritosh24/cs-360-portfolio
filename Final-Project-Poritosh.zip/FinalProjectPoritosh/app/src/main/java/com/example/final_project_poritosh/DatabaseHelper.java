package com.example.final_project_poritosh;

// DatabaseHelper.java
public class DatabaseHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "WeightTrackingDB";
    private static final int DATABASE_VERSION = 1;

    private static final String TABLE_DAILY_WEIGHT = "DailyWeight";
    private static final String TABLE_GOAL_WEIGHT = "GoalWeight";
    private static final String TABLE_USERS = "Users";

    private static final String CREATE_DAILY_WEIGHT_TABLE =
            "CREATE TABLE " + TABLE_DAILY_WEIGHT + " (id INTEGER PRIMARY KEY, date TEXT, weight REAL)";
    private static final String CREATE_GOAL_WEIGHT_TABLE =
            "CREATE TABLE " + TABLE_GOAL_WEIGHT + " (id INTEGER PRIMARY KEY, goal_weight REAL)";
    private static final String CREATE_USERS_TABLE =
            "CREATE TABLE " + TABLE_USERS + " (id INTEGER PRIMARY KEY, username TEXT, password TEXT)";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_DAILY_WEIGHT_TABLE);
        db.execSQL(CREATE_GOAL_WEIGHT_TABLE);
        db.execSQL(CREATE_USERS_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Handle database upgrades if needed
    }
}

