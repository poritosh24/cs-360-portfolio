package com.example.final_project_poritosh;

// LoginActivity.java
public class LoginActivity extends AppCompatActivity {
    private EditText usernameEditText, passwordEditText;
    private Button loginButton, registerButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        usernameEditText = findViewById(R.id.usernameEditText);
        passwordEditText = findViewById(R.id.passwordEditText);
        loginButton = findViewById(R.id.loginButton);
        registerButton = findViewById(R.id.registerButton);

        // Implement login button click event
        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String username = usernameEditText.getText().toString();
                String password = passwordEditText.getText().toString();

                // Check username and password against the database
                if (isValidUser(username, password)) {
                    // Redirect to dashboard or other screens
                    startActivity(new Intent(LoginActivity.this, DashboardActivity.class));
                } else {
                    // Show error message
                    Toast.makeText(LoginActivity.this, "Invalid credentials", Toast.LENGTH_SHORT).show();
                }
            }
        });

        // Implement register button click event
        registerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Redirect to registration screen
                startActivity(new Intent(LoginActivity.this, RegisterActivity.class));
            }
        });
    }

    // Replace this with actual database validation
    private boolean isValidUser(String username, String password) {
        String[] validUsernames = {"user1", "user2", "user3"};
        String[] validPasswords = {"password1", "password2", "password3"};

        for (int i = 0; i < validUsernames.length; i++) {
            if (username.equals(validUsernames[i]) && password.equals(validPasswords[i])) {
                return true; // User is valid
            }
        }

        return false; // User is not valid
    }
}

