package com.example.final_project_poritosh;

import android.Manifest;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.telephony.SmsManager;
import android.widget.Toast;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class NotificationManager {
    private Context context;

    public NotificationManager(Context context) {
        this.context = context;
    }

    public void requestSmsPermissions() {
        // Check if SMS permission is already granted
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {
            // Request SMS permission from the user
            ActivityCompat.requestPermissions((Activity) context,
                    new String[]{Manifest.permission.SEND_SMS},
                    SMS_PERMISSION_REQUEST_CODE);
        }
    }

    public void sendSmsNotification(String phoneNumber, String message) {
        // Check if SMS permission is granted
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED) {
            try {
                // Create an intent for sending SMS
                Intent smsIntent = new Intent(Intent.ACTION_SENDTO);
                smsIntent.setData(Uri.parse("smsto:" + phoneNumber));
                smsIntent.putExtra("sms_body", message);

                // Create a pending intent
                PendingIntent pendingIntent = PendingIntent.getActivity(context, 0, smsIntent, 0);

                // Get the default SMS manager and send the SMS
                SmsManager smsManager = SmsManager.getDefault();
                smsManager.sendTextMessage(phoneNumber, null, message, pendingIntent, null);

                Toast.makeText(context, "SMS Sent", Toast.LENGTH_SHORT).show();
            } catch (Exception e) {
                Toast.makeText(context, "Failed to send SMS", Toast.LENGTH_SHORT).show();
                e.printStackTrace();
            }
        } else {
            // SMS permission not granted, request it
            requestSmsPermissions();
        }
    }
}
