package com.example.final_project_poritosh;

// NotificationUtils.java
public class NotificationUtils {
    public static void showGoalAttainmentNotification(Context context) {
        NotificationCompat.Builder builder = new NotificationCompat.Builder(context, CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_notification)
                .setContentTitle("Goal Achieved!")
                .setContentText("Congratulations! You've reached your goal weight.")
                .setPriority(NotificationCompat.PRIORITY_DEFAULT);

        NotificationManagerCompat notificationManager = NotificationManagerCompat.from(context);
        notificationManager.notify(notificationId, builder.build());
    }
}

