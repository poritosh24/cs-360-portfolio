package com.example.final_project_poritosh;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class WeightEntryActivity extends AppCompatActivity {
    private EditText weightEditText;
    private Button saveButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_weight_entry);

        weightEditText = findViewById(R.id.weightEditText);
        saveButton = findViewById(R.id.saveButton);

        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String weightStr = weightEditText.getText().toString();
                if (!TextUtils.isEmpty(weightStr)) {
                    double weight = Double.parseDouble(weightStr);
                    // Save weight to the database
                    saveWeightToDatabase(weight);
                    Toast.makeText(WeightEntryActivity.this, "Weight saved to the database.", Toast.LENGTH_SHORT).show();
                    // Finish this activity or navigate to another screen
                    finish();
                } else {
                    Toast.makeText(WeightEntryActivity.this, "Please enter a valid weight.", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private void saveWeightToDatabase(double weight) {
        // Assuming you have a DatabaseHelper instance
        DatabaseHelper dbHelper = new DatabaseHelper(this);

        // Get a writable database
        SQLiteDatabase db = dbHelper.getWritableDatabase();

        // Create a ContentValues object to store the data
        ContentValues values = new ContentValues();
        values.put("date", getCurrentDate()); // You need to implement this method
        values.put("weight", weight);

        // Insert the data into the "DailyWeight" table
        long newRowId = db.insert("DailyWeight", null, values);

        // Check if the insertion was successful
        if (newRowId != -1) {
            // Data inserted successfully
        } else {
            // Failed to insert data
        }

        // Close the database connection
        db.close();
    }

    // Implement a method to get the current date
    private String getCurrentDate() {
        // You can implement this method to get the current date in the desired format
        // For example, you can use SimpleDateFormat to format the date
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
        Date currentDate = new Date();
        return dateFormat.format(currentDate);
    }
}
